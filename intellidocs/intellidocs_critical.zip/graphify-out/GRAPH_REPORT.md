# Graph Report - intellidocs  (2026-06-18)

## Corpus Check
- 132 files · ~81,818 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 582 nodes · 682 edges · 25 communities detected
- Extraction: 93% EXTRACTED · 7% INFERRED · 0% AMBIGUOUS · INFERRED: 49 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Community 0|Community 0]]
- [[_COMMUNITY_Community 1|Community 1]]
- [[_COMMUNITY_Community 2|Community 2]]
- [[_COMMUNITY_Community 3|Community 3]]
- [[_COMMUNITY_Community 4|Community 4]]
- [[_COMMUNITY_Community 5|Community 5]]
- [[_COMMUNITY_Community 6|Community 6]]
- [[_COMMUNITY_Community 7|Community 7]]
- [[_COMMUNITY_Community 8|Community 8]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]

## God Nodes (most connected - your core abstractions)
1. `normalizeBlock()` - 12 edges
2. `getRedisClient()` - 9 edges
3. `detect_issues()` - 9 edges
4. `main()` - 8 edges
5. `build_issue()` - 8 edges
6. `consumeAIQuota()` - 7 edges
7. `predictFormatting()` - 7 edges
8. `chatWithAI()` - 7 edges
9. `getUserId()` - 7 edges
10. `buildChatContext()` - 7 edges

## Surprising Connections (you probably didn't know these)
- `handleSubmit()` --calls--> `login()`  [INFERRED]
  frontend/src/pages/Login.tsx → server/src/controllers/authController.ts
- `handleSubmit()` --calls--> `login()`  [INFERRED]
  frontend/src/pages/Register.tsx → server/src/controllers/authController.ts
- `grammarCheck()` --calls--> `requestGrammarCheck()`  [INFERRED]
  server/src/controllers/predictionController.ts → server/src/ai/bridge/pythonBridge.ts
- `spellingCheck()` --calls--> `requestSpellingCheck()`  [INFERRED]
  server/src/controllers/predictionController.ts → server/src/ai/bridge/pythonBridge.ts
- `appendBehaviorEvent()` --calls--> `getRedisClient()`  [INFERRED]
  server/src/models/behaviorModel.ts → server/src/utils/redisClient.ts

## Communities

### Community 0 - "Community 0"
Cohesion: 0.05
Nodes (52): main(), Evaluate grammar score differences on JFLEG pairs., build_issue(), build_structural_matrix(), build_training_frame(), calibrate_score(), detect_article_mismatch(), detect_issues() (+44 more)

### Community 1 - "Community 1"
Cohesion: 0.07
Nodes (43): build_context(), build_training_row(), classify_page_type(), ensure_parent_directory(), estimate_body_font_size(), extract_academic_examples(), extract_line_from_spans(), extract_pdf_lines() (+35 more)

### Community 2 - "Community 2"
Cohesion: 0.06
Nodes (25): requestAggregation(), requestFeatureExport(), requestFeatureExtraction(), requestFormatPrediction(), requestGrammarCheck(), requestSpellingCheck(), buildBehaviorSummary(), extractFormatFromAction() (+17 more)

### Community 3 - "Community 3"
Cohesion: 0.12
Nodes (13): blockquote(), bulletList(), clearFormatting(), codeBlock(), getCurrentBlockTag(), heading1(), heading2(), heading3() (+5 more)

### Community 4 - "Community 4"
Cohesion: 0.11
Nodes (24): BaseModel, ensure_export_dir(), export_features(), main(), table_exists(), build_feature_row(), grammar_check(), health_check() (+16 more)

### Community 5 - "Community 5"
Cohesion: 0.21
Nodes (17): enforceQuota(), getText(), getUserId(), grammarCheck(), predictFormatting(), spellingCheck(), buildSuggestionCacheKey(), cacheSuggestion() (+9 more)

### Community 6 - "Community 6"
Cohesion: 0.15
Nodes (20): build_formatting_rows(), build_grammar_rows(), compute_features(), ensure_directory(), generate_synthetic_examples(), infer_format_label(), load_jsonl(), main() (+12 more)

### Community 7 - "Community 7"
Cohesion: 0.16
Nodes (16): buildHistoryMessages(), chatWithAI(), detectFormattingPreview(), getProviderSummary(), buildAIChatSystemPrompt(), formatRejectedFormattingPreviews(), buildChatContext(), decodeHtmlEntities() (+8 more)

### Community 8 - "Community 8"
Cohesion: 0.16
Nodes (13): formatPreviewLabel(), handlePreviewApply(), hasRejectedPreview(), parseMcpArgs(), parseMcpCommand(), send(), clearSelection(), getSelectedText() (+5 more)

### Community 10 - "Community 10"
Cohesion: 0.2
Nodes (15): download_jfleg(), download_wikitext(), ensure_directory(), main(), Create a directory if it does not already exist., Save each split in a dataset dictionary as JSONL files., Write simple metadata about the downloaded datasets., Download WikiText-103 raw and save it locally. (+7 more)

### Community 11 - "Community 11"
Cohesion: 0.17
Nodes (15): build_issue(), check_spelling(), edit_distance(), extract_words(), is_reliable_correction(), main(), Extract candidate words from text for spell checking., Build a structured spelling issue payload. (+7 more)

### Community 12 - "Community 12"
Cohesion: 0.19
Nodes (14): evaluate_model(), load_training_data(), main(), Load the processed formatting dataset from disk., Select numeric feature columns used for model training., Split the dataset into train and validation sets., Train a simple baseline formatting classifier., Evaluate the model on the validation split. (+6 more)

### Community 13 - "Community 13"
Cohesion: 0.15
Nodes (3): login(), handleSubmit(), handleSubmit()

### Community 14 - "Community 14"
Cohesion: 0.22
Nodes (12): load_user_features(), main(), parse_args(), Parse CLI arguments for fine-tuning., Load formatting_features rows for one user., Select numeric feature columns for training., Train a user-specific RandomForest model., Save the user-specific model to disk. (+4 more)

### Community 15 - "Community 15"
Cohesion: 0.26
Nodes (8): assignDocumentToFolder(), createFolder(), getDefaultFolder(), getDocumentsForFolder(), getFolderById(), getOrCreateDefaultFolder(), requireDocument(), requireFolder()

### Community 16 - "Community 16"
Cohesion: 0.36
Nodes (8): AIClientError, buildBody(), chat(), getConfig(), getProviderSummary(), readErrorDetails(), readText(), stream()

### Community 17 - "Community 17"
Cohesion: 0.33
Nodes (8): collect_events(), ensure_schema(), main(), parse_timestamp(), run_once(), Flush Redis behavior events into DuckDB (one-shot)., Flush Redis behavior events into DuckDB (one-shot)., trigger_aggregation()

### Community 18 - "Community 18"
Cohesion: 0.46
Nodes (7): addDocumentToFolder(), createFolder(), deleteFolder(), getFolderDocuments(), getFolders(), getUserId(), renameFolder()

### Community 19 - "Community 19"
Cohesion: 0.39
Nodes (5): buildOAuth2Client(), exportFile(), getAuthUrl(), handleCallback(), listFiles()

### Community 20 - "Community 20"
Cohesion: 0.43
Nodes (7): ensure_feature_table(), extract_features(), main(), overwrite_features(), Run feature extraction on DuckDB behavior_events table., Run feature extraction on DuckDB behavior_events table., trigger_feature_extraction()

### Community 21 - "Community 21"
Cohesion: 0.38
Nodes (6): load_model(), main(), Load model + feature columns., Select validation/test split if present; otherwise use holdout., Evaluate formatting prediction model., select_eval_frame()

### Community 28 - "Community 28"
Cohesion: 0.83
Nodes (3): getAppParams(), getAppParamValue(), toSnakeCase()

### Community 32 - "Community 32"
Cohesion: 1.0
Nodes (2): buildGrammarResult(), runCheck()

### Community 34 - "Community 34"
Cohesion: 1.0
Nodes (2): fetchAPI(), getAuthToken()

### Community 35 - "Community 35"
Cohesion: 0.67
Nodes (1): cn()

## Knowledge Gaps
- **111 isolated node(s):** `Load the trained base formatting model from disk.`, `Build the same numeric features used during base model training.`, `Return a simple welcome payload.`, `Return a health check payload.`, `Predict a formatting label for the given text.` (+106 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **Thin community `Community 32`** (3 nodes): `buildGrammarResult()`, `runCheck()`, `GrammarPanel.tsx`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 34`** (3 nodes): `api.ts`, `fetchAPI()`, `getAuthToken()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.
- **Thin community `Community 35`** (3 nodes): `utils.js`, `utils.ts`, `cn()`
  Too small to be a meaningful cluster - may be noise or needs more connections extracted.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `evaluate_text()` connect `Community 0` to `Community 4`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `grammar_check()` connect `Community 4` to `Community 0`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **Why does `load_dataset()` connect `Community 10` to `Community 0`?**
  _High betweenness centrality (0.010) - this node is a cross-community bridge._
- **Are the 8 inferred relationships involving `getRedisClient()` (e.g. with `appendBehaviorEvent()` and `getBehaviorEvents()`) actually correct?**
  _`getRedisClient()` has 8 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Load the trained base formatting model from disk.`, `Build the same numeric features used during base model training.`, `Return a simple welcome payload.` to the rest of the system?**
  _111 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.05 - nodes in this community are weakly interconnected._
- **Should `Community 1` be split into smaller, more focused modules?**
  _Cohesion score 0.07 - nodes in this community are weakly interconnected._