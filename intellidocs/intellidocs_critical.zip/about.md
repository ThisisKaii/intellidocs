# About IntelliDocs
> This document provides full context about IntelliDocs for AI 
> assistance in writing Chapters 1–3 of the research paper. 
> Please read this in full before assisting with any research 
> writing tasks.

---

## 1. System Overview

IntelliDocs is a web-based intelligent document editor that learns 
individual users' text-level formatting behavior and automatically 
suggests formatting with confidence scoring. It is built using the 
PERN stack (PostgreSQL, Express, React, Node.js) with a Python 
FastAPI microservice for machine learning.

IntelliDocs is **not** a replacement for Word or Google Docs. It 
fills a specific, narrow gap: no existing document editor learns 
an individual user's formatting habits and predicts them 
automatically. Competing tools (Word, Google Docs, Grammarly, 
ChatGPT/Claude document tools) either require manual formatting 
or apply formatting reactively based on explicit instructions — 
none of them learn and personalize formatting behavior over time.

---

## 2. Target Users

The primary target users are **students and professors** writing 
structured academic documents — research papers, theses, capstone 
projects, reports, and academic feedback documents. These users 
repeatedly apply similar formatting patterns (headings, emphasis, 
lists, spacing) across long documents, and IntelliDocs reduces 
this repetitive manual effort.

---

## 3. Problem Statement

People have been formatting documents manually for years. Even 
with tools like MS Word styles, formatting remains repetitive and 
becomes increasingly exhausting as a document grows larger. While 
general-purpose AI tools (ChatGPT, Claude) can format documents 
when explicitly instructed, they are reactive — they have no 
memory of a user's formatting preferences across sessions and 
cannot anticipate formatting needs without being asked.

IntelliDocs addresses this gap by learning a user's individual 
formatting behavior over time and proactively suggesting 
formatting with a visible confidence score, allowing users to 
focus on writing content rather than structuring it.

---

## 4. Research Objectives

1. Identify current document formatting processes and workflows, 
   and identify problems encountered such as repetitive manual 
   formatting.
2. Determine mechanisms and techniques for learning and predicting 
   individual user formatting behavior automatically.
3. Determine the best features and machine learning models for 
   accurately predicting formatting decisions based on document 
   context.
4. Propose a confidence-scoring mechanism that surfaces 
   high-certainty formatting suggestions to users in a 
   non-intrusive way.

---

## 5. Scope

### In Scope (Text-Level Formatting & Integration)
- Bold, italic, underline, strikethrough
- Headings (H1–H6)
- Text alignment
- Font size, font color, text highlight color
- Lists (ordered and unordered)
- Paragraph spacing
- Text indentation
- Superscript / subscript
- **Google Drive API Integration**: Allows OAuth2-authenticated users to import native Google Docs directly into the editor (automatically converting the source document to contentEditable-compliant HTML).

### Out of Scope (Document-Level Formatting — Future Enhancement)
- Tables
- Image upload
- Graphs/charts
- Page margins, page size, columns
- Headers and footers
- Complex template formats (e.g., IEEE, formal letters)

---

## 6. System Architecture

### Tech Stack

**Frontend**
- React 18 + Vite + TypeScript
- Shadcn/ui + Tailwind CSS (UI primitives only)
- Custom contentEditable-based document editor (built from 
  scratch, no third-party editor libraries such as TipTap, 
  ProseMirror, or Quill — required for full control over 
  behavioral tracking)

**Backend**
- Node.js 20 + Express + TypeScript
- Strict MVC architecture (routes → controllers → models, zero 
  business logic in routes, zero direct DB access in controllers)

**Databases**
- Supabase (PostgreSQL + Auth + Realtime + pgvector) — primary 
  relational data store, source of truth for users, documents, 
  folders, suggestions, and feedback
- Upstash Redis — high-frequency behavioral event buffer, 
  suggestion caching, debounced auto-save, AI request quota 
  tracking
- DuckDB — analytical store for aggregated behavioral data used 
  in ML training

**AI / ML**
- Python 3 + FastAPI — ML prediction microservice
- scikit-learn RandomForestClassifier — primary formatting 
  prediction model (hybrid rule-based + ML approach)
- Logistic Regression (trained on JFLEG dataset using Trigram TF-IDF lexical sequences) + NLTK Part-of-Speech (POS) Tagging — hybrid grammar correction pipeline; Logistic Regression handles lexical context and sequence probability, while NLTK POS-tagging performs context-aware syntactic rule parsing (such as subject-verb agreement and tense consistency) completely on the CPU without high compute requirements.
- pyspellchecker — spelling correction
- Gemini 3.5 Flash (Google AI Studio) — conversational AI 
  assistant, used only when the user explicitly interacts with 
  the chat overlay; orchestrates MCP tools but performs no 
  formatting actions itself

### AI Integration via MCP (Model Context Protocol)
The AI chatbot (Gemini) operates entirely separately from the 
core formatting prediction pipeline. Gemini only activates when 
a user explicitly opens the chat overlay. It calls MCP tools 
(exposed by the Express server) to read document state, retrieve 
behavioral summaries, or apply formatting changes — but the 
actual execution of any action is always performed by the 
system's own code, never by the AI directly. This ensures the 
core system functions fully even if the AI provider is 
unavailable.

### 6.2 System Modules & Core Functionalities

IntelliDocs is structured into six interdependent system modules that implement the core functionalities required to support personalized document writing:

```mermaid
graph TD
    A[Document Management Module] -->|Opens Document| B[Custom Text Editor Module]
    B -->|Sends Keystrokes & Selections| C[Behavior Ingestion & Analytics Pipeline]
    C -->|Flushes logs| D[ML Formatting & Layout Prediction Module]
    B -->|Checks Quality| E[Context-Aware Grammar & Spelling Checker]
    F[Interactive AI Chat Overlay & MCP] -->|Calls Local Tools| B
```

#### 1. Document Management Module
*   **System Functionalities**:
    *   *File Manager*: Provides a Google Drive-inspired navigation view with folder trees, search, sorting filters, owner initials, and list layouts.
    *   *CRUD Operations*: Manages creating, renaming, moving, opening, and soft-deleting documents in PostgreSQL.
    *   *Google Drive OAuth2 Import*: Interacts with Google Cloud APIs to retrieve and export Google Docs as clean semantic HTML, rendering them directly in the text editor.

#### 2. Custom Text Editor Module
*   **System Functionalities**:
    *   *WYSWIG Editor*: Employs a custom `contentEditable` writing area that bypasses third-party libraries (TipTap/ProseMirror) to maintain raw selection tracking.
    *   *Formatting Control*: Features standard toolbar buttons (Bold, Italic, Headings, Lists) which apply formatting manually via browser selection commands.
    *   *Markdown Shortcuts*: Detects markdown character sequences inline (e.g. typing `# ` or `- `) and translates them immediately to document styles.

#### 3. Behavior Ingestion & Analytics Pipeline
*   **System Functionalities**:
    *   *Event Listener*: Tracks every keypress, formatting toggle, and suggestion action (accept/reject) directly inside the custom editor.
    *   *High-Frequency Buffer*: Channels event logs instantly to Upstash Redis to keep writing latency at zero.
    *   *Analytical Storage*: Periodically runs `aggregator.py` to flush Redis events into a local DuckDB instance, organizing raw logs into a structured history.

#### 4. ML Formatting & Layout Prediction Module
*   **System Functionalities**:
    *   *Layout Classification*: Evaluates the current block of text on character count, capitalization ratios, line breaks, and punctuation to predict formatting labels (heading, paragraph, list).
    *   *Personalized Fine-Tuner*: Once a user logs 50 behavior events in DuckDB, a personal Scikit-Learn `RandomForestClassifier` is trained (`fine_tuner.py`) and loaded, overriding base model predictions.

#### 5. Context-Aware Grammar & Spelling Checker
*   **System Functionalities**:
    *   *Spell Check*: Leverages the `pyspellchecker` library to identify typos and output corrections.
    *   *POS Syntactic Check*: Employs NLTK Part-of-Speech tagging to check syntactic agreement (e.g., matching singular nouns to singular verbs, verifying tense consistency in parallel clauses).
    *   *Lexical Sequence Score*: Uses a Logistic Regression model trained on JFLEG dataset (with Trigram TF-IDF features) to generate a grammar quality score between 0.0 and 1.0.

#### 6. Interactive AI Chat Overlay & MCP Integration
*   **System Functionalities**:
    *   *Conversational Side Panel*: Offers a floating sidebar chat powered by Gemini 3.5 Flash for conversational queries about document content.
    *   *MCP Tool Execution*: Uses Model Context Protocol (MCP) tool specifications to allow the model to fetch document text, read formatting history, and propose styling revisions, executing them locally.

#### 7. Data Isolation & Privacy Control
*   **System Functionalities**:
    *   *Isolate Toggle*: Enables a document-level flag (`is_isolated`) that stops the behavioral event logger from saving keystroke and formatting metrics to Redis or DuckDB.
    *   *History Sanitation*: Cleanses existing DuckDB and Redis behavioral records associated with a document if it is transitioned into isolation mode.

### 6.3 Core System Flows & Data Lifecycles

IntelliDocs operates via four core data and interaction flows:

#### 1. Format Prediction & Feedback Loop (Real-Time UI Flow)

```mermaid
sequenceDiagram
    participant User as User / Editor
    participant FE as React Frontend
    participant BE as Express Backend
    participant ML as Python FastAPI
    
    User->>FE: Types text or changes line
    FE->>BE: POST /api/predictions/predict
    BE->>ML: POST /predict (via pythonBridge)
    ML->>ML: Extract features & predict layout
    ML-->>BE: Returns prediction + confidence score
    BE-->>FE: Returns prediction payload
    FE->>User: Displays inline recommendation (🟢/🟡)
    User->>FE: Accepts (Tab) or rejects (ignores) suggestion
    FE->>BE: POST /api/behavior/log (feedback capture)
    BE->>BE: Queue event in Redis buffer
```

*   **Flow Steps**:
    1.  The user types text or enters a new line in `EditorCore.tsx`.
    2.  `useBehaviorLogger` triggers a debounced layout prediction API call to Express.
    3.  Express uses `pythonBridge.ts` to forward the text block to FastAPI's `/predict` endpoint.
    4.  FastAPI builds the feature matrix, checks rules, executes layout classification, and returns the predicted label along with the probability score.
    5.  The frontend receives the prediction and renders an inline visual highlight in the `SuggestionOverlay` if confidence $\ge$ 60%.
    6.  The user either accepts the formatting recommendation (using the `Tab` key) or rejects it (by moving the cursor away).
    7.  The user decision triggers a feedback log post-request to `/api/behavior/log`, which Express buffers directly into Redis.

#### 2. Behavior Ingestion & Personalization Pipeline (Background ML Flow)

```mermaid
sequenceDiagram
    participant Redis as Redis Buffer
    participant Aggregator as aggregator.py
    participant DuckDB as DuckDB Analytical DB
    participant FT as fine_tuner.py
    
    Note over Redis, DuckDB: Occurs in the background asynchronously
    Aggregator->>Redis: Pulls queued formatting events
    Redis-->>Aggregator: Returns raw event payload
    Aggregator->>DuckDB: Appends events to behavior_events table
    Note over DuckDB, FT: Triggered when user events count >= 50
    FT->>DuckDB: Query formatting_features table for user_id
    DuckDB-->>FT: Returns feature rows
    FT->>FT: Retrains RandomForest model per user
    FT->>FT: Saves model_{user_id}.pkl to disk
```

*   **Flow Steps**:
    1.  User formatting interactions are buffered as event payloads in Redis.
    2.  An asynchronous service running `aggregator.py` pulls logs out of Redis and inserts them into DuckDB's `behavior_events` table.
    3.  FastAPI's `/pipeline/extract-features` calculates numerical features and popops them into DuckDB's `formatting_features` table.
    4.  When a user's local events count crosses 50, a training cycle `/train_user` triggers `fine_tuner.py`.
    5.  `fine_tuner.py` pulls the user's features from DuckDB, fine-tunes the `RandomForestClassifier` weights, and saves a customized model pickle file (`model_{user_id}.pkl`).
    6.  Subsequent prediction requests for that `user_id` load the customized model from disk, completing the personalization loop.

#### 3. Google Drive Document Import Flow (OAuth2 Integration Flow)

```mermaid
sequenceDiagram
    participant User as User Dashboard
    participant FE as React Frontend
    participant BE as Express Backend
    participant Google as Google Drive API
    participant DB as Supabase PostgreSQL
    
    User->>FE: Clicks "Import from Drive"
    FE->>BE: Initiates OAuth redirection URL
    BE-->>FE: Returns authorization URL
    FE->>Google: Redirects user to consent screen
    Google-->>BE: Code sent to redirect_uri callback
    BE->>Google: Exchanges code for tokens
    BE->>DB: Stores refresh token linked to user_id
    BE->>Google: Requests Doc export (text/html)
    Google-->>BE: Returns document HTML content
    BE-->>FE: Returns clean, sanitized HTML
    FE->>User: Renders document directly in custom editor
```

*   **Flow Steps**:
    1.  The user clicks the Google Drive import button in the dashboard sidebar.
    2.  The application routes the user to the Google OAuth consent interface.
    3.  On user consent, Google redirects back to `/google/callback` with an auth code.
    4.  Express exchanges the authorization code for access and refresh tokens, saving the refresh token in Supabase.
    5.  Express requests Google Drive API to export the chosen doc ID as `text/html`.
    6.  Express cleans, parses, and sends the sanitized HTML response to React, which updates the `contentEditable` document state.

#### 4. Grammar & Spelling Quality Check Flow
*   **Flow Steps**:
    1.  The custom editor monitors keyboard input and triggers a debounced quality check.
    2.  The React app posts the text content to backend `/api/grammar/check`.
    3.  Express routes the sentence to FastAPI's `/grammar/check` endpoint.
    4.  FastAPI executes spell-checking using `pyspellchecker` and calls NLTK to parse parts-of-speech, identifying verb tense shifts and pluralization agreement errors.
    5.  FastAPI scores lexical sentence quality using TF-IDF Trigrams with the JFLEG-trained Logistic Regression model, producing a composite quality score.
    6.  The editor underlines grammar suggestions in purple, revealing popover options on hover.

### 6.4 Database Schema & Entity Relationships

IntelliDocs separates transactional data, high-frequency logs, and analytical vectors into three database tiers.

#### 1. Relational Database Tier: Supabase (PostgreSQL)

Supabase PostgreSQL manages persistent transactional records, enforcing user-level security via Row Level Security (RLS) policies.

```mermaid
erDiagram
    users {
        uuid id PK
    }
    documents {
        uuid id PK
        uuid user_id FK
        text title
        text content
        jsonb formatting_history
        boolean is_isolated
        timestamptz created_at
        timestamptz updated_at
    }
    folders {
        uuid folder_id PK
        uuid user_id FK
        text name
        uuid parent_id FK
    }
    folder_documents {
        uuid folder_id PK, FK
        uuid document_id PK, FK
    }
    formatting_actions {
        uuid action_id PK
        uuid document_id FK
        uuid user_id FK
        text action_type
        text action_source
    }
    ai_suggestions {
        uuid suggestion_id PK
        uuid document_id FK
        uuid user_id FK
        text suggested_format
        numeric confidence
        text reason
        text status
    }
    suggestion_feedback {
        uuid feedback_id PK
        uuid suggestion_id FK
        uuid user_id FK
        text decision
    }
    grammar_issues {
        uuid issue_id PK
        uuid document_id FK
        uuid user_id FK
        text issue_type
        text original_text
        text suggestion_text
        timestamptz resolved_at
    }
    google_tokens {
        uuid user_id PK, FK
        text refresh_token
        text access_token
        bigint expiry_date
    }

    users ||--o{ documents : owns
    users ||--o{ folders : owns
    users ||--o{ formatting_actions : performs
    users ||--o{ ai_suggestions : receives
    users ||--o{ suggestion_feedback : decides
    users ||--o{ grammar_issues : has
    users ||--|| google_tokens : owns

    folders ||--o{ folders : nested
    folders ||--o{ folder_documents : groups
    documents ||--o{ folder_documents : in_folder
    documents ||--o{ formatting_actions : logs
    documents ||--o{ ai_suggestions : receives
    documents ||--o{ grammar_issues : logs
    ai_suggestions ||--|| suggestion_feedback : rates
```

##### Tables Dictionary

| Table Name | Primary Key | Foreign Keys | Key Columns | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| `documents` | `id` (UUID) | `user_id` $\rightarrow$ `auth.users` | `title`, `content`, `formatting_history` (JSONB history stack), `is_isolated` (privacy flag) | Stores core user document contents and layout metadata. |
| `folders` | `folder_id` (UUID) | `user_id` $\rightarrow$ `auth.users`, `parent_id` $\rightarrow$ `folders` | `name` (text) | Implements nesting folder hierarchy paths. |
| `folder_documents` | `(folder_id, document_id)` | `folder_id`, `document_id` | `added_at` (timestamptz) | Junction table linking files into parent directories. |
| `formatting_actions` | `action_id` (UUID) | `document_id` $\rightarrow$ `documents`, `user_id` $\rightarrow$ `auth.users` | `action_type`, `action_source` | Persists log actions to track editing history. |
| `ai_suggestions` | `suggestion_id` (UUID) | `document_id` $\rightarrow$ `documents`, `user_id` $\rightarrow$ `auth.users` | `suggested_format`, `confidence` (numeric), `status` (pending/accepted/rejected) | Stores formatting recommendations generated by ML. |
| `suggestion_feedback` | `feedback_id` (UUID) | `suggestion_id` $\rightarrow$ `ai_suggestions`, `user_id` $\rightarrow$ `auth.users` | `decision` (accept/reject) | Records explicit user feedback outcomes. |
| `grammar_issues` | `issue_id` (UUID) | `document_id` $\rightarrow$ `documents`, `user_id` $\rightarrow$ `auth.users` | `issue_type`, `original_text`, `suggestion_text`, `resolved_at` | Tracks grammar/spelling errors found in sentences. |
| `google_tokens` | `user_id` (UUID) | `user_id` $\rightarrow$ `auth.users` | `refresh_token`, `access_token`, `expiry_date` | Persists OAuth credentials for Google Drive access. |

---

#### 2. Cache Tier: Upstash Redis

Upstash Redis operates as an in-memory queue to absorb high-frequency front-end events and act as an application cache.

| Key Pattern | Data Type | Payload Fields | Purpose |
| :--- | :--- | :--- | :--- |
| `behavior_buffer:{user_id}` | List (FIFO) | `{"event_id": str, "document_id": str, "action_type": str, "timestamp": str}` | Queues active typing/selection events before DuckDB ingestion. |
| `suggestion_cache:{document_id}` | String / JSON | `{"predicted_format": str, "confidence": float}` | Caches ML layout responses to speed up cursor reposition requests. |
| `user_quota:{user_id}` | String / Numeric | Token bucket count (integer) | Enforces AI request quotas (rate limiting) to manage provider expenses. |
| `autosave_dirty:{document_id}`| Set | String document IDs | Marks documents with pending changes to trigger debounced auto-saves. |

---

#### 3. Analytical Tier: DuckDB

DuckDB is a columnar, embedded SQL database optimized for analytical aggregation queries and feature extraction.

##### Table: `behavior_events` (Aggregated logs)
*   `event_id` (VARCHAR, PK)
*   `user_id` (VARCHAR)
*   `document_id` (VARCHAR)
*   `action_type` (VARCHAR) — e.g. `format_bold`, `format_heading1`, `accept_suggestion`
*   `timestamp` (TIMESTAMP)
*   `session_id` (VARCHAR)

##### Table: `formatting_features` (ML training records)
*   `user_id` (VARCHAR, PK component)
*   `char_count` (INTEGER) — character length of block
*   `word_count` (INTEGER) — word count of block
*   `line_count` (INTEGER) — text line count
*   `uppercase_ratio` (DOUBLE) — percentage of capital letters
*   `digit_ratio` (DOUBLE) — percentage of numerical digits
*   `punctuation_ratio` (DOUBLE) — percentage of punctuation marks
*   `heading_depth` (INTEGER) — depth level (0 if paragraph)
*   `label` (VARCHAR) — Target class label (e.g. `paragraph`, `heading1`, `list`)

---

## 7. Machine Learning Approach

### Two-Phase / Hierarchical Training Pipeline
1. **Phase 1 — General Pre-training (WikiText-103)**: The base 
   RandomForest model is pre-trained on WikiText-103, a dataset 
   sourced from Wikipedia containing naturally structured text 
   with clear formatting patterns (headings, paragraphs, lists). 
   This dataset was chosen because it provides the foundational 
   formatting conventions (heading structure, paragraph length, 
   marker usage) needed before the system can personalize to 
   individual users — solving the "cold start" problem.
2. **Phase 2 — Domain-Specific Refinement (planned)**: An 
   additional academic dataset (e.g., arXiv papers) to narrow 
   the model from general text to academic writing conventions.
3. **Phase 3 — Institutional Refinement**: Prior research papers 
   from the institution, narrowing the model to the school's 
   specific academic formatting culture. Two prior research papers 
   have already been identified and are ready to be used for this 
   phase, along with a formatting template/guideline for 
   IntelliDocs' own future research paper (Chapters 1–3), which 
   will also be fed into the model to reinforce the target 
   formatting conventions this system itself is expected to follow.
4. **Phase 4 — Personalization (Fine-tuning)**: Individual user 
   behavioral data (captured via Redis → DuckDB → 
   `fine_tuner.py`) personalizes the model per user. The 
   personalized model overrides the base model's predictions as 
   confidence in the user-specific model grows. If a user has no 
   personalized model yet, the system falls back to the base 
   model.

### Dataset Used (WikiText-103) — Actual Statistics
- Total records: 1,170,381
- Labels: `paragraph` (73.80%), `heading1` (26.18%), 
  `unordered_list` (0.02%), `ordered_list` (0.00%)
- Features (7 numeric, original extraction): `char_count`, 
  `word_count`, `line_count`, `uppercase_ratio`, `digit_ratio`, 
  `punctuation_ratio`, `starts_with_marker`
- Initial finding: `starts_with_marker` was the strongest 
  predictor in the raw WikiText-103 data — 100% present in 
  heading1, unordered_list, and ordered_list records, but only 
  0.05% in paragraph records
- Paragraphs average 612.7 characters; heading1 averages 26.0 
  characters — nearly a 24x difference

### Revised Feature Set — Removing Marker Dependency
`starts_with_marker` is a WikiText-specific artifact (the `= =` 
wiki syntax used to denote headings/lists) and does not reflect 
how real users write in a document editor — real documents do not 
contain wiki markup. Relying on this feature would make the model 
unable to generalize beyond WikiText-formatted text.

`starts_with_marker` is therefore **dropped from the feature set**. 
The model instead learns to predict formatting purely from 
**contextual signals** that generalize to real writing:
- `char_count` / `word_count` — short text segments are more 
  likely to be headings/lists, long segments are more likely to 
  be paragraphs
- `line_count` — single-line segments vs multi-line blocks
- `uppercase_ratio` — headings tend to have higher capitalization
- `punctuation_ratio` — paragraphs typically end in terminal 
  punctuation; headings often do not
- `digit_ratio` — useful for detecting ordered list patterns
- Position-based context (e.g., position in document, distance 
  from previous heading) — planned additional features for future 
  training phases

This makes the model's predictions based on **how the text reads**, 
not on whether it contains wiki-style syntax — a requirement for 
the model to work correctly on real user-authored documents.

### Markdown-Style Command Formatting (Separate from ML Prediction)
In addition to (and separate from) the ML-based formatting 
prediction, IntelliDocs supports **markdown-style command 
shortcuts**, similar to Discord or Notion. These are 
**user-typed triggers** that immediately apply formatting, 
independent of the ML model:

- `**text**` → applies bold to `text`
- `# text` → converts the line to heading1
- `- text` or `* text` → converts the line to a list item
- (additional shortcuts to be defined as needed)

This separates two distinct mechanisms:
1. **ML-based prediction** — the system observes context and 
   *suggests* formatting with a confidence score (the user 
   accepts/rejects)
2. **Command-based formatting** — the user *explicitly* types a 
   known syntax and the formatting is applied immediately, no 
   prediction or confidence involved

The markdown markers that previously existed only as a WikiText 
artifact are repurposed here as an intentional, user-facing 
feature.

### Hybrid Prediction
The system combines `rule_based_predict()` and `ml_predict()`, 
using whichever produces a higher confidence score. The 
confidence score (derived from RandomForest's `predict_proba()`) 
is always shown to the user.

### Confidence-Based Suggestion UI
Rather than a centralized popup, formatting suggestions appear 
**inline, directly on the affected text** — similar to Grammarly's 
underline pattern. Each suggestion type (heading, bold, list, 
etc.) has a distinct visual indicator with an inline 
accept/reject control, so the user can clearly see exactly what 
will change before confirming.

- High confidence (≥85%): suggestion shown prominently, quick 
  accept via keyboard shortcut
- Medium confidence (60–84%): suggestion shown subtly, requires 
  hover or click to view
- Low confidence (<60%): suggestion not shown, to avoid alert 
  fatigue

---

## 8. Behavioral Learning Pipeline

1. User performs a formatting action (or accepts/rejects a 
   suggestion) in the editor.
2. The action is captured by `BehaviorListener.ts` and sent to 
   Redis (high-frequency buffer).
3. `aggregator.py` periodically flushes Redis data into DuckDB 
   (analytical store).
4. When a user accumulates sufficient interaction data (a 
   defined threshold), `fine_tuner.py` trains a personalized 
   model: `model_{user_id}.pkl`.
5. The prediction service checks for a personalized model first; 
   if none exists, it falls back to the base model.

---

## 9. Proposed Feature: Document Isolation Mode ("Isolate Document")

**Status: Proposed / Not Yet Implemented**

This is a privacy-focused feature under consideration for the 
system. When a user enables "Isolate Document" for a specific 
document:

- All formatting actions and suggestion responses within that 
  document are **excluded from the behavioral learning pipeline** 
  — they are not sent to Redis/DuckDB and do not influence the 
  user's personalized model (`fine_tuner.py`).
- If the document had previously contributed behavioral data to 
  the user's global model **before** isolation was enabled, that 
  prior contribution is removed from the global behavioral 
  dataset going forward.
- The document continues to function normally — predictions are 
  still shown (from the base model or the user's current 
  personalized model), and the document's final content/
  formatting state (`formatting_history`) is still saved normally.
- The only thing isolated is the **learning loop** — this document 
  will never teach the system anything about the user's habits, 
  and the system will not use this document's history to inform 
  predictions in other documents.

**Rationale**: Some documents (e.g., a one-off letter, a document 
with deliberately unusual formatting, or a sensitive/confidential 
document) may contain formatting patterns that do not represent 
the user's typical habits. Without isolation, these atypical 
patterns could "pollute" the user's personalized model. This 
feature gives users explicit control over what does and does not 
shape their personalized formatting profile, directly supporting 
data privacy and user control principles.

---

## 10. Ethical Considerations

- User behavioral data is collected only with awareness and used 
  exclusively to personalize that individual user's model — never 
  shared across accounts.
- Confidence scores are always visible before any suggestion is 
  applied; nothing changes without explicit user confirmation.
- Users can delete all their behavioral data at any time, with 
  full removal across Redis, DuckDB, and PostgreSQL.
- Grammar and spelling assistance only targets surface-level 
  errors — the system never alters the substance or voice of the 
  user's writing.
- (Proposed) Document Isolation Mode gives users granular control 
  over which documents contribute to their personalization model.

---

## 11. Data Limitations

- **Cold start problem**: New users have no behavioral data, so 
  the system relies entirely on the base model trained on 
  WikiText-103 until sufficient interactions are logged.
- **Dataset imbalance**: WikiText-103 is heavily skewed toward 
  paragraph (73.80%), which can bias predictions toward paragraph 
  for ambiguous inputs without proper handling (e.g., SMOTE, class 
  weighting).
- **Domain mismatch**: WikiText-103 reflects English Wikipedia 
  writing conventions, which may not fully generalize to academic, 
  legal, medical, or informal writing styles without additional 
  domain-specific training data (planned Phases 2–3).
- **Complex/template formats**: Highly structured formats (IEEE 
  papers, formal letters) involve document-level layout decisions 
  that text-level behavioral learning cannot predict — an 
  acknowledged scope limitation.

---

## 12. Real-World Implications

If formatting behavior can be learned and predicted with 
measurable confidence, document editors can reduce the cognitive 
overhead of manual formatting — particularly for students and 
researchers who follow consistent but unconscious formatting 
patterns. This approach could extend beyond academic writing to 
legal document drafting, medical record writing, and enterprise 
content management — any domain where users follow consistent but 
unconscious formatting conventions that a system can learn and 
anticipate.

---

## 13. Key Design Rationales (The "Whys")

During the capstone defense, the panel will ask for justifications of key design choices. Here are the core architectural "whys":

### 1. Why build a custom contentEditable editor instead of using TipTap / ProseMirror?
*   **The "Why":** Standard editor libraries abstract the document DOM into their own internal state representations (e.g., ProseMirror's transaction state). To study raw behavioral formatting (RO1), we need low-level, high-fidelity capture of selection ranges, keypress timings, and formatting triggers. Wrapping native `contentEditable` gives us direct access to the DOM selection API and browser events, eliminating library-induced latency or event abstraction.

### 2. Why use NLTK POS Tagging + Trigram Logistic Regression instead of a Transformer for grammar?
*   **The "Why":** A deep learning Transformer (like RoBERTa or DistilBERT) requires heavy GPU computation and easily exceeds VRAM limits on standard consumer/student hardware (e.g. RTX 3050 6GB). NLTK POS Tagging runs in milliseconds on a single CPU core to detect structural syntax issues (subject-verb agreement), while Trigram TF-IDF captures local lexical context. This keeps the editor lightweight and local while retaining context-awareness.

### 3. Why use WikiText-103 for pre-training before user fine-tuning?
*   **The "Why":** A personalized model cannot make suggestions for a new user because there is no historical data (the "cold start" problem). WikiText-103 contains over 1 million Wikipedia articles containing naturally formatted headers, lists, and paragraphs. Pre-training on this corpus establishes baseline formatting conventions (e.g. headings are short and highly capitalized), which are then customized as user logs accumulate.

### 4. Why use a tiered DB structure (Supabase + Redis + DuckDB)?
*   **The "Why":** 
    *   **Supabase (PostgreSQL)** is our primary transactional relational database, handling critical persistent state (documents, folders, user auth).
    *   **Redis** acts as a high-speed, volatile buffer to ingest behavioral events (keypresses, selections, formatting commands) in real-time without bottlenecking the main database.
    *   **DuckDB** is an embedded columnar database designed for analytics, allowing us to perform fast, local SQL queries and feature extraction for machine learning without impacting transactional PostgreSQL performance.

### 5. Why implement a Document Isolation Mode?
*   **The "Why":** Research papers or templates have very different formatting rules than daily notes. If a user writes an unusual document, its logging would pollute their global personalization weights. Isolation mode gives the user control to preserve model hygiene and guarantees privacy for sensitive content by preventing logs from entering the analytics loop.

### 6. Why use inline indicators instead of blocking overlays?
*   **The "Why":** Formatting is a continuous flow state. Popups or blocking dialogs create high cognitive friction and alert fatigue (RQ4). Underlining and inline text recommendations keep the writing process continuous and non-disruptive.

---

## 14. Notes for Research Paper Writing (Chapters 1–3)

- **Chapter 1 (Introduction)**: Use Sections 1–4 (System Overview, 
  Target Users, Problem Statement, Research Objectives) as the 
  foundation. Emphasize the gap-filling research position — 
  IntelliDocs is not competing with Word/Google Docs, it adds a 
  capability none of them have.
- **Chapter 2 (Review of Related Literature/Systems)**: Compare 
  against Microsoft Word (manual styles), Google Docs 
  (collaborative but not behavioral), Grammarly (grammar-focused, 
  not formatting-behavioral), and general AI assistants like 
  ChatGPT/Claude (reactive, stateless, no formatting memory across 
  sessions). The core differentiator is **behavioral, personalized, 
  proactive formatting prediction with confidence scoring** — no 
  reviewed system does this.
- **Chapter 3 (Methodology)**: Use Sections 5–9 (System 
  Architecture, ML Approach, Behavioral Learning Pipeline) as the 
  technical foundation. Be precise about the hierarchical training 
  pipeline (4 phases) and the hybrid prediction approach (rule-based 
  + ML, confidence-based). Use the actual WikiText-103 statistics 
  provided in Section 7 — do not estimate or invent numbers, these 
  are real results from the processed dataset.
- When discussing limitations or ethics, use Sections 10–11 
  directly — these are already scoped honestly and defensibly.
- The Document Isolation Mode (Section 9) is a **proposed** 
  feature. If included in the paper, it should be framed as part 
  of the system design / future work depending on whether it has 
  been implemented by the time of writing — confirm with the group 
  before presenting it as a completed feature.
- **Google Drive Import**: Emphasize how OAuth2 integration supports RO1 (analyzing user formatting workflows) and RO2 by easing content import without manual copy-paste errors.

---

## 15. Future Roadmap & Development Phases

To progress from the current prototype to a production capstone system, the development has been partitioned into 5 key phases:

1. **Phase 1 — Document Isolation Mode**: Implementing metadata flags (`is_isolated`) in PostgreSQL, allowing users to toggle logging exclusion. This addresses a core ethical and data-hygiene consideration.
2. **Phase 2 — Lightweight Context-Aware POS & N-Gram Grammar Pipeline**: Transitioning grammar checkers to run NLTK-based POS syntactic rules (detecting subject-verb mismatches or tense shifts) and Trigram TF-IDF Logistic Regression, bypassing high VRAM constraints while retaining sequence-aware correction.
3. **Phase 3 — Google Drive OAuth2 Integration**: Adding full authentication flow and content ingestion via Google Docs export, automatically converting document bodies to semantic `contentEditable`-compatible HTML.
4. **Phase 4 — Personalization & Fine-Tuning**: Initiating automatic background model fine-tuning (`fine_tuner.py`) once a user accumulates 50 events in DuckDB, allowing personalized weights to overwrite base model predictions.
5. **Phase 5 — Inline Confidence Score Visualizer**: Replacing modal feedback cards with inline visual hints (green text insert recommendations, purple underlines, and Tab-key autocomplete trigger) to lower cognitive friction.
