import { motion, AnimatePresence } from 'framer-motion';
import { Brain, X } from 'lucide-react';
import { applyFormat, FORMAT_LABELS } from '@/lib/formatCommands';

export default function SuggestionPanel({ suggestions, onApply, onDismiss }) {
  if (!suggestions || suggestions.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 8 }}
        transition={{ duration: 0.2 }}
        className="bg-card border border-accent/25 rounded-lg shadow-sm overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-accent/5">
          <div className="flex items-center gap-2">
            <Brain className="w-3.5 h-3.5 text-accent" />
            <span className="font-inter text-xs font-semibold tracking-wider uppercase text-accent">
              ML Predictions
            </span>
          </div>
          <button onMouseDown={(e) => { e.preventDefault(); onDismiss(); }} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Suggestions */}
        <div className="p-2 space-y-1">
          {suggestions.map((s, i) => (
            <button
            key={i}
            onMouseDown={(e) => {
              e.preventDefault(); // preserve editor focus & selection
              applyFormat(s.format);
              onApply(s.format);
            }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md hover:bg-secondary transition-colors text-left group"
            >
              {/* Confidence bar */}
              <div className="flex-shrink-0 w-8 h-8 rounded-md bg-accent/10 flex items-center justify-center">
                <span className="font-inter text-[10px] font-bold text-accent">{s.confidence}%</span>
              </div>

              <div className="flex-1 min-w-0">
                <p className="font-inter text-sm font-medium text-foreground">
                  {FORMAT_LABELS[s.format] || s.format}
                </p>
                <p className="font-inter text-xs text-muted-foreground truncate">{s.reason}</p>
              </div>

              {/* Confidence bar visual */}
              <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden flex-shrink-0">
                <div
                  className="h-full bg-accent rounded-full transition-all"
                  style={{ width: `${s.confidence}%` }}
                />
              </div>
            </button>
          ))}
        </div>

        <div className="px-4 py-2 border-t border-border">
          <p className="font-inter text-xs text-muted-foreground italic">
            Learned from your formatting history
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}