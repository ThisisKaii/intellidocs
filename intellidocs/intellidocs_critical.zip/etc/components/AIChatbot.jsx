import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Loader2, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { applyFormat, parseAICommand, FORMAT_LABELS } from '@/lib/formatCommands';

export default function AIChatbot({ documentId, documentContent, onFormatApplied }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hello! I\'m your IntelliDocs AI assistant. I can format your document using natural language — try "make the selected text bold", "turn this into a heading", or "add a blockquote".',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function send() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(m => [...m, { role: 'user', content: userMsg }]);
    setLoading(true);

    const response = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an AI formatting assistant for IntelliDocs, a document editor. 
The user has the following request: "${userMsg}"

The document context is:
"${(documentContent || '').slice(0, 800)}"

Your task:
1. Understand what formatting the user wants to apply.
2. Respond with a short, helpful explanation of what you're doing.
3. End your response with EXACTLY one of these format commands on its own line if formatting is needed:
   APPLY:bold, APPLY:italic, APPLY:underline, APPLY:h1, APPLY:h2, APPLY:h3, APPLY:blockquote, APPLY:ul, APPLY:ol, APPLY:align-left, APPLY:align-center, APPLY:align-right

If no formatting command is needed (e.g. the user is just asking a question), don't include an APPLY line.
Keep your response under 60 words. Be friendly and precise.`,
    });

    const text = typeof response === 'string' ? response : response?.text || '';

    // Extract APPLY command
    const applyMatch = text.match(/APPLY:(\S+)/);
    let appliedFormat = null;
    if (applyMatch) {
      const fmt = applyMatch[1];
      applyFormat(fmt);
      appliedFormat = fmt;
      onFormatApplied?.(fmt);
    }

    const cleanText = text.replace(/APPLY:\S+/, '').trim();

    const assistantMsg = {
      role: 'assistant',
      content: cleanText,
      command_applied: appliedFormat,
    };

    setMessages(m => [...m, assistantMsg]);
    setLoading(false);

    // Persist to DB
    if (documentId) {
      base44.entities.ChatMessage.create({
        document_id: documentId,
        role: 'user',
        content: userMsg,
      });
      base44.entities.ChatMessage.create({
        document_id: documentId,
        role: 'assistant',
        content: cleanText,
        command_applied: appliedFormat,
      });
    }
  }

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center shadow-md hover:opacity-90 transition-opacity"
        title="AI Assistant"
      >
        {open ? <X className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
      </button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.96 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-14 right-0 w-80 bg-card border border-border rounded-xl shadow-lg overflow-hidden z-50"
          >
            {/* Header */}
            <div className="flex items-center gap-2.5 px-4 py-3 border-b border-border bg-secondary/50">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-primary-foreground" />
              </div>
              <div>
                <p className="font-inter text-sm font-semibold">AI Assistant</p>
                <p className="font-inter text-xs text-muted-foreground">Natural language formatting</p>
              </div>
            </div>

            {/* Messages */}
            <div className="h-64 overflow-y-auto p-3 space-y-3">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-[85%] px-3 py-2 rounded-lg font-inter text-sm leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-secondary text-foreground'
                    }`}
                  >
                    {m.content}
                    {m.command_applied && (
                      <div className="mt-1.5 text-xs opacity-70 flex items-center gap-1">
                        ✓ Applied: {FORMAT_LABELS[m.command_applied] || m.command_applied}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-secondary px-3 py-2 rounded-lg">
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="border-t border-border p-3 flex gap-2">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && send()}
                placeholder="Type a formatting command..."
                className="flex-1 text-sm font-inter bg-secondary rounded-md px-3 py-2 outline-none placeholder:text-muted-foreground focus:ring-1 focus:ring-accent/40"
              />
              <button
                onClick={send}
                disabled={!input.trim() || loading}
                className="p-2 bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity disabled:opacity-40"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}