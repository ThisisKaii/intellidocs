import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, CheckCircle2, Loader2, ChevronDown, ChevronUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function GrammarPanel({ text, onCheckComplete }) {
  const [issues, setIssues] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);

  async function runCheck() {
    if (!text || text.length < 10) return;
    setLoading(true);
    setIssues(null);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a grammar and spell checker. Analyze the following text and return a JSON object listing any grammar or spelling issues.

Text to check:
"""
${text.slice(0, 1500)}
"""

Return a JSON with this exact structure:
{
  "issues": [
    { "type": "grammar" | "spelling", "original": "the wrong text", "suggestion": "the correct text", "explanation": "brief reason" }
  ],
  "overall": "brief 1-sentence overall assessment"
}

If there are no issues, return {"issues": [], "overall": "No issues found."}
Limit to the 5 most important issues.`,
      response_json_schema: {
        type: 'object',
        properties: {
          issues: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                original: { type: 'string' },
                suggestion: { type: 'string' },
                explanation: { type: 'string' },
              },
            },
          },
          overall: { type: 'string' },
        },
      },
    });

    setIssues(result);
    setLoading(false);
    onCheckComplete?.(result?.issues || []);
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <button
        onMouseDown={(e) => { e.preventDefault(); setExpanded(v => !v); }}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-secondary/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-muted-foreground" />
          <span className="font-inter text-sm font-medium">Grammar & Spell Check</span>
          {issues && (
            <span className={`text-xs font-inter px-2 py-0.5 rounded-full ${
              issues.issues?.length === 0
                ? 'bg-green-100 text-green-700'
                : 'bg-destructive/10 text-destructive'
            }`}>
              {issues.issues?.length === 0 ? 'Clean' : `${issues.issues.length} issue${issues.issues.length !== 1 ? 's' : ''}`}
            </span>
          )}
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t border-border pt-3">
              <button
                onMouseDown={(e) => { e.preventDefault(); runCheck(); }}
                disabled={loading || !text}
                className="w-full flex items-center justify-center gap-2 bg-secondary hover:bg-muted transition-colors text-sm font-inter font-medium px-4 py-2 rounded-md disabled:opacity-50"
              >
                {loading ? (
                  <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Checking…</>
                ) : (
                  <>Check document</>
                )}
              </button>

              {issues && (
                <div className="mt-3 space-y-2">
                  {issues.overall && (
                    <p className="font-inter text-xs text-muted-foreground italic">{issues.overall}</p>
                  )}
                  {issues.issues?.length === 0 ? (
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle2 className="w-4 h-4" />
                      <span className="font-inter text-sm">No issues found</span>
                    </div>
                  ) : (
                    issues.issues?.map((issue, i) => (
                      <div key={i} className="bg-destructive/5 border border-destructive/15 rounded-md p-3">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <span className={`font-inter text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded ${
                            issue.type === 'grammar'
                              ? 'bg-orange-100 text-orange-700'
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {issue.type}
                          </span>
                        </div>
                        <p className="font-inter text-xs">
                          <span className="line-through text-muted-foreground">{issue.original}</span>
                          {' → '}
                          <span className="font-medium text-foreground">{issue.suggestion}</span>
                        </p>
                        {issue.explanation && (
                          <p className="font-inter text-xs text-muted-foreground mt-1">{issue.explanation}</p>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}