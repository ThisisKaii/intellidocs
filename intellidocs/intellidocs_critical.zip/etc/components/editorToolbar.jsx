import { applyFormat, isFormatActive } from '@/lib/formatCommands';
import {
  Bold, Italic, Underline, Heading1, Heading2, Heading3,
  Quote, List, ListOrdered, AlignLeft, AlignCenter, AlignRight
} from 'lucide-react';

const TOOLBAR_GROUPS = [
  [
    { format: 'bold', icon: Bold, label: 'Bold' },
    { format: 'italic', icon: Italic, label: 'Italic' },
    { format: 'underline', icon: Underline, label: 'Underline' },
  ],
  [
    { format: 'h1', icon: Heading1, label: 'Heading 1' },
    { format: 'h2', icon: Heading2, label: 'Heading 2' },
    { format: 'h3', icon: Heading3, label: 'Heading 3' },
  ],
  [
    { format: 'blockquote', icon: Quote, label: 'Blockquote' },
    { format: 'ul', icon: List, label: 'Bullet list' },
    { format: 'ol', icon: ListOrdered, label: 'Numbered list' },
  ],
  [
    { format: 'align-left', icon: AlignLeft, label: 'Align left' },
    { format: 'align-center', icon: AlignCenter, label: 'Align center' },
    { format: 'align-right', icon: AlignRight, label: 'Align right' },
  ],
];

export default function EditorToolbar({ onFormat, activeFormats = {} }) {
  function handleClick(format) {
    applyFormat(format);
    onFormat(format);
  }

  return (
    <div className="flex items-center gap-1 flex-wrap">
      {TOOLBAR_GROUPS.map((group, gi) => (
        <div key={gi} className="flex items-center gap-0.5">
          {gi > 0 && <div className="w-px h-5 bg-border mx-1.5" />}
          {group.map(({ format, icon: Icon, label }) => {
            const active = activeFormats[format] || isFormatActive(format);
            return (
              <button
                key={format}
                onMouseDown={(e) => {
                  e.preventDefault();
                  handleClick(format);
                }}
                title={label}
                className={`p-2 rounded-md transition-colors ${
                  active
                    ? 'bg-accent/15 text-accent'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}