import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { predictor } from '@/lib/predictor';
import { FORMAT_LABELS } from '@/lib/formatCommands';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Sparkles, ArrowLeft, Brain, TrendingUp, FileText, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const COLORS = ['#B8894A', '#8B6635', '#D4A96A', '#7A5C2E', '#C9A070', '#6B4F25'];

export default function Insights() {
  const [actions, setActions] = useState([]);
  const [docs, setDocs] = useState([]);
  const [localStats, setLocalStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.FormatAction.list('-created_date', 200),
      base44.entities.Document.list('-updated_date', 50),
    ]).then(([acts, d]) => {
      setActions(acts);
      setDocs(d);
      setLocalStats(predictor.getStats());
      setLoading(false);
    });
  }, []);

  const formatCounts = actions.reduce((acc, a) => {
    acc[a.format_type] = (acc[a.format_type] || 0) + 1;
    return acc;
  }, {});

  const barData = Object.entries(formatCounts)
    .map(([fmt, count]) => ({ name: FORMAT_LABELS[fmt] || fmt, count }))
    .sort((a, b) => b.count - a.count);

  const pieData = barData.slice(0, 6);

  const totalActions = actions.length;
  const totalWords = docs.reduce((s, d) => s + (d.word_count || 0), 0);
  const mostUsed = barData[0]?.name || '—';
  const localPatterns = Object.keys(localStats).length;

  const stats = [
    { label: 'Total format actions', value: totalActions, icon: Zap },
    { label: 'Words written', value: totalWords.toLocaleString(), icon: FileText },
    { label: 'Most used format', value: mostUsed, icon: TrendingUp },
    { label: 'Patterns learned', value: localPatterns, icon: Brain },
  ];

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b border-border px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link to="/documents" className="text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-7 h-7 bg-primary rounded-sm flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
            </div>
            <span className="font-fraunces font-semibold text-lg tracking-tight">IntelliDocs</span>
          </Link>
        </div>
        <span className="font-inter text-sm text-muted-foreground">Behavioral Insights</span>
      </nav>

      <main className="max-w-5xl mx-auto px-6 py-12">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="font-fraunces text-4xl font-light mb-2">Your writing patterns</h1>
          <p className="font-inter text-sm text-muted-foreground mb-10">
            Aggregate analysis of your formatting behavior across all documents.
          </p>

          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
            {stats.map(({ label, value, icon: Icon }) => (
              <div key={label} className="bg-card border border-border rounded-lg p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Icon className="w-4 h-4 text-accent" />
                  <span className="font-inter text-xs text-muted-foreground uppercase tracking-wide">{label}</span>
                </div>
                <p className="font-fraunces text-3xl font-light">{value}</p>
              </div>
            ))}
          </div>

          {loading ? (
            <div className="h-64 bg-secondary animate-pulse rounded-lg" />
          ) : totalActions === 0 ? (
            <div className="text-center py-20 border border-dashed border-border rounded-lg">
              <Brain className="w-10 h-10 text-muted-foreground mx-auto mb-4 opacity-40" />
              <p className="font-fraunces text-xl text-muted-foreground mb-2">No data yet</p>
              <p className="font-inter text-sm text-muted-foreground">
                Start formatting documents and your patterns will appear here.
              </p>
              <Link to="/documents" className="inline-block mt-5 text-sm text-accent hover:underline">
                Open the editor →
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Bar chart */}
              <div className="lg:col-span-2 bg-card border border-border rounded-lg p-6">
                <h2 className="font-fraunces text-lg font-medium mb-6">Format frequency</h2>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={barData} barSize={28}>
                    <XAxis
                      dataKey="name"
                      tick={{ fontSize: 11, fontFamily: 'Inter', fill: '#9C8E7E' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fontFamily: 'Inter', fill: '#9C8E7E' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        background: 'hsl(36 25% 98%)',
                        border: '1px solid hsl(36 15% 87%)',
                        borderRadius: '6px',
                        fontFamily: 'Inter',
                        fontSize: 12,
                      }}
                    />
                    <Bar dataKey="count" fill="hsl(35 43% 50%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Pie chart */}
              <div className="bg-card border border-border rounded-lg p-6">
                <h2 className="font-fraunces text-lg font-medium mb-6">Distribution</h2>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={pieData} dataKey="count" nameKey="name" cx="50%" cy="50%" outerRadius={70} innerRadius={35}>
                      {pieData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: 'hsl(36 25% 98%)',
                        border: '1px solid hsl(36 15% 87%)',
                        borderRadius: '6px',
                        fontFamily: 'Inter',
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-2">
                  {pieData.slice(0, 4).map((d, i) => (
                    <div key={d.name} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: COLORS[i] }} />
                      <span className="font-inter text-xs text-muted-foreground flex-1 truncate">{d.name}</span>
                      <span className="font-inter text-xs font-medium">{d.count}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Local predictor patterns */}
              <div className="lg:col-span-3 bg-card border border-border rounded-lg p-6">
                <h2 className="font-fraunces text-lg font-medium mb-2">ML predictor — learned patterns</h2>
                <p className="font-inter text-xs text-muted-foreground mb-6">
                  These are the in-browser learned patterns from your current device session.
                </p>
                {Object.keys(localStats).length === 0 ? (
                  <p className="font-inter text-sm text-muted-foreground">No patterns learned yet.</p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {Object.entries(localStats)
                      .sort(([,a],[,b]) => b - a)
                      .map(([fmt, count]) => (
                        <div key={fmt} className="bg-secondary/60 rounded-md px-3 py-2.5">
                          <div className="font-inter text-xs font-semibold text-accent mb-0.5">
                            {FORMAT_LABELS[fmt] || fmt}
                          </div>
                          <div className="font-fraunces text-xl font-light">{count}</div>
                          <div className="font-inter text-xs text-muted-foreground">uses</div>
                        </div>
                      ))
                    }
                  </div>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </main>
    </div>
  );
}