import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { predictor } from '@/lib/predictor';
import { applyFormat } from '@/lib/formatCommands';

import EditorToolbar from '@/components/editor/EditorToolbar';
import SuggestionPanel from '@/components/editor/SuggestionPanel';
import AIChatbot from '@/components/editor/AIChatbot';
import GrammarPanel from '@/components/editor/GrammarPanel';
import FormatPrompt from '@/components/editor/FormatPrompt';
import { Sparkles, ArrowLeft, BarChart3, Save, ChevronDown, ChevronUp, Brain } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const AUTOSAVE_DELAY = 2000;
const PREDICT_DELAY = 600;

export default function Editor() {
  const { id } = useParams();
  const [doc, setDoc] = useState(null);
  const [title, setTitle] = useState('Untitled Document');
  const [saveStatus, setSaveStatus] = useState('saved'); // 'saved' | 'saving' | 'unsaved'
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [formatPrompt, setFormatPrompt] = useState(null); // { format, confidence }
  const [rightPanelOpen, setRightPanelOpen] = useState(true);
  const savedRange = useRef(null);
  const [wordCount, setWordCount] = useState(0);

  const editorRef = useRef(null);
  const autosaveTimer = useRef(null);
  const predictTimer = useRef(null);
  const sessionId = useRef(`session_${Date.now()}`);

  // Load document
  useEffect(() => {
    if (!id) return;
    base44.entities.Document.filter({ id }).then(docs => {
      const d = docs[0];
      if (d) {
        setDoc(d);
        setTitle(d.title || 'Untitled Document');
        if (editorRef.current && d.content) {
          editorRef.current.innerHTML = d.content;
          updateWordCount();
        }
      }
    });
  }, [id]);

  function updateWordCount() {
    const text = editorRef.current?.innerText || '';
    setWordCount(text.split(/\s+/).filter(Boolean).length);
  }

  // Auto-save
  function scheduleSave() {
    setSaveStatus('unsaved');
    clearTimeout(autosaveTimer.current);
    autosaveTimer.current = setTimeout(saveDocument, AUTOSAVE_DELAY);
  }

  async function saveDocument() {
    if (!id || !editorRef.current) return;
    setSaveStatus('saving');
    const content = editorRef.current.innerHTML;
    const wc = editorRef.current.innerText.split(/\s+/).filter(Boolean).length;
    await base44.entities.Document.update(id, {
      title,
      content,
      word_count: wc,
      last_saved: new Date().toISOString(),
    });
    setSaveStatus('saved');
  }

  // Predict on pause — if top prediction is confident enough, show YES/NO prompt
  function schedulePrediction() {
    clearTimeout(predictTimer.current);
    predictTimer.current = setTimeout(() => {
      const selection = window.getSelection();
      const selLen = selection?.toString()?.length || 0;
      const contextText = editorRef.current?.innerText?.slice(-200) || '';
      const preds = predictor.predict(contextText, selLen);
      if (preds.length > 0) {
        setSuggestions(preds);
        setShowSuggestions(true);
        // Auto-prompt if top prediction is sufficiently confident
        const top = preds[0];
        if (top.confidence >= 60) {
          // Save the current selection range so we can restore it on accept
          const sel = window.getSelection();
          if (sel && sel.rangeCount > 0) {
            savedRange.current = sel.getRangeAt(0).cloneRange();
          }
          setFormatPrompt(top);
        }
      }
    }, PREDICT_DELAY);
  }

  function handlePromptAccept(fmt) {
    // Restore saved selection, then focus editor, then apply format
    editorRef.current?.focus();
    if (savedRange.current) {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(savedRange.current);
      savedRange.current = null;
    }
    applyFormat(fmt);
    handleFormat(fmt);
    setFormatPrompt(null);
    setShowSuggestions(false);
  }

  function handlePromptReject() {
    setFormatPrompt(null);
    setShowSuggestions(false);
  }

  // Record format action
  async function handleFormat(formatType) {
    const selection = window.getSelection();
    const selLen = selection?.toString()?.length || 0;
    const contextText = editorRef.current?.innerText?.slice(-200) || '';

    // Learn the pattern
    predictor.record(formatType, contextText, selLen);

    // Persist to DB
    if (id) {
      base44.entities.FormatAction.create({
        document_id: id,
        format_type: formatType,
        context_before: contextText.slice(-80),
        context_type: selLen > 0 ? (selLen < 30 ? 'word' : 'sentence') : 'cursor',
        position: editorRef.current?.innerText?.length || 0,
        session_id: sessionId.current,
      });
    }

    setShowSuggestions(false);
    scheduleSave();
    updateWordCount();
  }

  function handleEditorInput() {
    scheduleSave();
    schedulePrediction();
    updateWordCount();
  }

  function handleKeyDown(e) {
    // Keyboard shortcuts
    if (e.ctrlKey || e.metaKey) {
      switch (e.key) {
        case 'b': e.preventDefault(); handleFormat('bold'); applyFormat('bold'); break;
        case 'i': e.preventDefault(); handleFormat('italic'); applyFormat('italic'); break;
        case 'u': e.preventDefault(); handleFormat('underline'); applyFormat('underline'); break;
        default: break;
      }
    }
  }

  const getEditorText = useCallback(() => editorRef.current?.innerText || '', []);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="flex items-center gap-4 px-6 py-3">
          {/* Left */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <Link to="/documents" className="text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
            </Link>
            <Link to="/" className="flex items-center gap-1.5">
              <div className="w-6 h-6 bg-primary rounded-sm flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-primary-foreground" />
              </div>
              <span className="font-fraunces font-semibold text-sm tracking-tight hidden sm:block">IntelliDocs</span>
            </Link>
          </div>

          {/* Title */}
          <input
            value={title}
            onChange={e => { setTitle(e.target.value); scheduleSave(); }}
            className="flex-1 font-fraunces text-base font-medium bg-transparent outline-none text-foreground placeholder:text-muted-foreground text-center min-w-0"
            placeholder="Document title…"
          />

          {/* Right */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <span className="font-inter text-xs text-muted-foreground hidden sm:block">
              {wordCount} words
            </span>
            <span className={`font-inter text-xs flex items-center gap-1 ${
              saveStatus === 'saving' ? 'text-accent' :
              saveStatus === 'unsaved' ? 'text-muted-foreground' :
              'text-muted-foreground'
            }`}>
              <Save className="w-3 h-3" />
              {saveStatus === 'saving' ? 'Saving…' : saveStatus === 'unsaved' ? 'Unsaved' : 'Saved'}
            </span>
            <Link to="/insights" className="text-muted-foreground hover:text-foreground transition-colors" title="Insights">
              <BarChart3 className="w-4 h-4" />
            </Link>
            <button
              onClick={() => setRightPanelOpen(o => !o)}
              className="flex items-center gap-1.5 text-xs font-inter text-muted-foreground hover:text-foreground transition-colors border border-border px-2.5 py-1.5 rounded-md"
            >
              <Brain className="w-3.5 h-3.5" />
              <span className="hidden sm:block">AI Panel</span>
            </button>
          </div>
        </div>

        {/* Toolbar */}
        <div className="px-6 py-2 border-t border-border/60">
          <EditorToolbar onFormat={handleFormat} />
        </div>
      </header>

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Editor */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-2xl mx-auto px-8 py-12">
            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleEditorInput}
              onKeyDown={handleKeyDown}
              className="intellidocs-editor min-h-[60vh] focus:outline-none"
              data-placeholder="Begin writing…"
              style={{ '--placeholder-color': 'hsl(30 10% 70%)' }}
            />
          </div>
        </main>

        {/* Right panel */}
        <AnimatePresence>
          {rightPanelOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 300, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="border-l border-border bg-card/60 overflow-hidden flex-shrink-0"
            >
              <div className="w-[300px] p-4 space-y-4 h-full overflow-y-auto">
                {/* ML Suggestions */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-inter text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      Predictions
                    </span>
                    {!showSuggestions && (
                      <span className="font-inter text-xs text-muted-foreground">Type to activate…</span>
                    )}
                  </div>
                  <SuggestionPanel
                    suggestions={suggestions}
                    onApply={(fmt) => {
                      handleFormat(fmt);
                      setShowSuggestions(false);
                    }}
                    onDismiss={() => setShowSuggestions(false)}
                  />
                  {!showSuggestions && (
                    <div className="bg-secondary/60 rounded-lg p-4 text-center">
                      <Brain className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                      <p className="font-inter text-xs text-muted-foreground">
                        Predictions appear as you type and format
                      </p>
                    </div>
                  )}
                </div>

                {/* Grammar */}
                <GrammarPanel text={getEditorText()} />

                {/* Stats */}
                <div className="bg-card border border-border rounded-lg p-4">
                  <p className="font-inter text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Session</p>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-inter text-xs text-muted-foreground">Words</span>
                      <span className="font-inter text-xs font-medium">{wordCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-inter text-xs text-muted-foreground">Session ID</span>
                      <span className="font-inter text-xs font-medium font-mono opacity-50">
                        {sessionId.current.slice(-6)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* Format Prompt — YES/NO floating bar */}
      <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50" style={{ pointerEvents: formatPrompt ? 'all' : 'none' }}>
        <FormatPrompt
          suggestion={formatPrompt}
          onAccept={handlePromptAccept}
          onReject={handlePromptReject}
        />
      </div>

      {/* Floating AI Chatbot */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2" style={{ position: 'fixed' }}>
        <div className="relative">
          <AIChatbot
            documentId={id}
            documentContent={getEditorText()}
            onFormatApplied={handleFormat}
          />
        </div>
      </div>
    </div>
  );
}