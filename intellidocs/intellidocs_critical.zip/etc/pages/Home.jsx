import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Brain, FileText, MessageSquare, BarChart3, Sparkles, ChevronRight } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'ML-Powered Predictions',
    desc: 'Learns your formatting patterns in real time. Predicts your next move with confidence scores — before you apply it.',
  },
  {
    icon: FileText,
    title: 'Custom Editor',
    desc: 'Built from scratch with the contentEditable API. No third-party editor libraries. Pure, semantic HTML output.',
  },
  {
    icon: MessageSquare,
    title: 'AI Chatbot',
    desc: 'Type "make this a heading" or "bold the title" — natural language commands that format your document instantly.',
  },
  {
    icon: BarChart3,
    title: 'Behavioral Insights',
    desc: 'Visualize how you write and format. Understand your own patterns with academic-grade analytics.',
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Nav */}
      <nav className="border-b border-border px-8 py-5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-primary rounded-sm flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-fraunces font-semibold text-lg tracking-tight">IntelliDocs</span>
        </div>
        <div className="flex items-center gap-6">
          <Link to="/documents" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Documents</Link>
          <Link to="/insights" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Insights</Link>
          <Link
            to="/documents"
            className="text-sm bg-primary text-primary-foreground px-4 py-2 rounded-md hover:opacity-90 transition-opacity font-medium"
          >
            Open Editor
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center px-6 py-24 text-center max-w-4xl mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="inline-flex items-center gap-2 text-xs font-inter font-semibold tracking-widest uppercase text-accent border border-accent/30 bg-accent/8 px-3 py-1.5 rounded-full mb-8">
            <Brain className="w-3 h-3" />
            Research Instrument · ML + Behavioral Analysis
          </div>

          <h1 className="font-fraunces text-5xl sm:text-6xl lg:text-7xl font-light leading-[1.05] tracking-tight text-foreground mb-6">
            The editor that
            <br />
            <span className="italic text-accent">learns</span> how you write
          </h1>

          <p className="font-inter text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto mb-10">
            IntelliDocs combines machine learning with behavioral analysis to predict and suggest 
            formatting automatically — before you even apply it.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/documents"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-md font-inter font-medium text-sm hover:opacity-90 transition-opacity"
            >
              Start writing <ChevronRight className="w-4 h-4" />
            </Link>
            <Link
              to="/insights"
              className="inline-flex items-center gap-2 border border-border text-foreground px-6 py-3 rounded-md font-inter font-medium text-sm hover:bg-secondary transition-colors"
            >
              <BarChart3 className="w-4 h-4" /> View insights
            </Link>
          </div>
        </motion.div>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="mt-24 grid grid-cols-1 sm:grid-cols-2 gap-6 text-left w-full"
        >
          {features.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-lg p-6 hover:border-accent/40 transition-colors"
            >
              <div className="w-9 h-9 bg-accent/10 rounded-md flex items-center justify-center mb-4">
                <Icon className="w-4.5 h-4.5 text-accent" style={{ width: '1.1rem', height: '1.1rem' }} />
              </div>
              <h3 className="font-fraunces font-semibold text-base mb-2">{title}</h3>
              <p className="font-inter text-sm text-muted-foreground leading-relaxed">{desc}</p>
            </div>
          ))}
        </motion.div>
      </main>

      <footer className="border-t border-border px-8 py-5 flex items-center justify-between text-xs text-muted-foreground font-inter">
        <span>IntelliDocs — Research Prototype</span>
        <span>ML + Behavioral Document Analysis</span>
      </footer>
    </div>
  );
}