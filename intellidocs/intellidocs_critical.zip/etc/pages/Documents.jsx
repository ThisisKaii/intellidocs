import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Plus, FileText, Trash2, Clock, ChevronRight, BarChart3 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function Documents() {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    base44.entities.Document.list('-updated_date', 50).then(d => {
      setDocs(d);
      setLoading(false);
    });
  }, []);

  async function createDoc() {
    setCreating(true);
    const doc = await base44.entities.Document.create({
      title: 'Untitled Document',
      content: '',
      word_count: 0,
    });
    navigate(`/editor/${doc.id}`);
  }

  async function deleteDoc(e, id) {
    e.preventDefault();
    e.stopPropagation();
    await base44.entities.Document.delete(id);
    setDocs(d => d.filter(doc => doc.id !== id));
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="border-b border-border px-8 py-5 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-primary rounded-sm flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary-foreground" />
          </div>
          <span className="font-fraunces font-semibold text-lg tracking-tight">IntelliDocs</span>
        </Link>
        <div className="flex items-center gap-4">
          <Link to="/insights" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <BarChart3 className="w-4 h-4" /> Insights
          </Link>
          <button
            onClick={createDoc}
            disabled={creating}
            className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-inter font-medium hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            <Plus className="w-4 h-4" /> New document
          </button>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-10">
          <h1 className="font-fraunces text-4xl font-light mb-2">Your Documents</h1>
          <p className="font-inter text-sm text-muted-foreground">
            {docs.length} document{docs.length !== 1 ? 's' : ''} · ML predictions learn from each session
          </p>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => (
              <div key={i} className="h-20 bg-secondary animate-pulse rounded-lg" />
            ))}
          </div>
        ) : docs.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20 border border-dashed border-border rounded-lg"
          >
            <FileText className="w-10 h-10 text-muted-foreground mx-auto mb-4 opacity-40" />
            <p className="font-fraunces text-xl mb-2 text-muted-foreground">No documents yet</p>
            <p className="font-inter text-sm text-muted-foreground mb-6">Create your first document to start training the predictor.</p>
            <button
              onClick={createDoc}
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-md text-sm font-inter font-medium hover:opacity-90 transition-opacity"
            >
              <Plus className="w-4 h-4" /> Create document
            </button>
          </motion.div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {docs.map((doc, i) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: i * 0.04 }}
                >
                  <Link
                    to={`/editor/${doc.id}`}
                    className="flex items-center gap-4 bg-card border border-border rounded-lg px-5 py-4 hover:border-accent/40 hover:shadow-sm transition-all group"
                  >
                    <div className="w-9 h-9 bg-secondary rounded-md flex items-center justify-center flex-shrink-0">
                      <FileText className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-fraunces font-medium text-base truncate">{doc.title || 'Untitled'}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground font-inter">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(doc.updated_date), { addSuffix: true })}
                        </span>
                        {doc.word_count > 0 && (
                          <span className="text-xs text-muted-foreground font-inter">{doc.word_count} words</span>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => deleteDoc(e, doc.id)}
                        className="p-1.5 text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>
    </div>
  );
}