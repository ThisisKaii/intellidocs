## . User Formatting Controls

IntelliDocs operates on a three-tier formatting control system, 

giving users full control over how much or how little the system 

automates for them.

### Tier 1 — Presets

Predefined formatting templates that users can select when 

creating a new document. Presets provide an immediate formatting 

foundation, solving the cold start problem by giving the ML model 

a relevant baseline to build on rather than starting from zero.

Planned presets:

- Academic Research Paper

- Thesis / Dissertation

- Business Letter

- General Document

- Custom (user-built)

Presets are stored in Supabase as predefined formatting rule sets 

(jsonb). When selected, the preset rules are loaded as the 

document's initial formatting profile. Behavioral learning then 

personalizes on top of the preset over time.

### Tier 2 — Custom Format Bindings

Users can explicitly define their own formatting rules that the 

system always respects, regardless of what the ML model would 

predict. These are hard rules the user sets themselves:

Examples:

- "Whenever text is under 5 words on a standalone line, 

   always apply H2"

- "Bold is always for key terms, never for titles"

- "New sections always start with H2 followed by H3"

Custom bindings are stored per user in Supabase:

- trigger_condition (jsonb) — what context triggers the rule

- format_to_apply (text) — what formatting to apply

- priority (int) — which binding wins if multiple match

### Tier 3 — ML-Based Auto Formatting (Prediction)

When no preset rule or custom binding applies to the current 

context, the ML model predicts the appropriate formatting based 

on learned behavioral patterns and surfaces a suggestion inline 

with a confidence score for the user to accept or reject.

### How the Three Tiers Interact

User types text

       ↓

Does a custom binding match this context?

       ↓ YES → apply binding immediately, no prediction

       ↓ NO

Does an active preset rule apply?

       ↓ YES → apply preset rule

       ↓ NO

ML model predicts with confidence score

       ↓

Inline suggestion shown, user accepts or rejects

       ↓

Accepted suggestions feed into behavioral learning
